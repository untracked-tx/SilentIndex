import random

categories = [
    "withheld honesty",
    "tolerated imbalance",
    "emotional debt",
    "deferred confrontation",
    "unspoken care"
]

print("SilentIndex GHOST: Generating emotional invoice...
")

for item in random.sample(categories, 3):
    units = round(random.uniform(1.0, 5.0), 1)
    print(f"- {units} units of {item}")

print("
Total cost: future friction")
print("Recommended payment: silence
")
